with open("../Desktop/my_text.txt", mode="w") as file:
    contents = file.read()
    print(contents)
    file.close()


